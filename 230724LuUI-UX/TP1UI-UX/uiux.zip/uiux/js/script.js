// function showConfirmation(e) {
//     e.preventDefault();
//     let confirmationModal = new bootstrap.Modal(document.getElementById('confirmationModal'));
//     confirmationModal.show();
// }

// function hideConfirmation() {
//     let confirmationModal = new bootstrap.Modal(document.getElementById('confirmationModal'));
//     confirmationModal.hide();
// }


 // Récupérer les éléments nécessaires
 const modal = document.getElementById("myModal");
 const btnOpen = document.getElementById("openBtn");
 const btnClose = document.getElementById("closeBtn");

 // Gérer l'événement clic pour ouvrir la modal
 btnOpen.addEventListener("click", function(e) {
    e.preventDefault();
   modal.style.display = "block"; // Afficher la modal
 });

 // Gérer l'événement clic pour fermer la modal
 btnClose.addEventListener("click", function() {
   modal.style.display = "none"; // Masquer la modal
 });

 // Gérer la fermeture de la modal lors du clic en dehors de celle-ci
 window.addEventListener("click", function(event) {
   if (event.target === modal) {
     modal.style.display = "none"; // Masquer la modal
   }
 });

 function toggleSubMenu() {
    let subMenu = document.getElementById("subMenu");
    if (subMenu.classList.contains("hidden")) {
        subMenu.classList.remove("hidden");
    } else {
        subMenu.classList.add("hidden");
    }
}

const form = document.querySelector("form");
const homepage = document.getElementById("homepage");
const fruitShop = document.getElementById("fruit-shop");
const syrupShop = document.getElementById("syrup-shop");
const cocktailShop = document.getElementById("cocktail-shop");

let current = homepage;

function changePage(page)
{
  if(page === current) return;
  
  current.hidden = true;
  page.hidden = false;

  current = page;
}