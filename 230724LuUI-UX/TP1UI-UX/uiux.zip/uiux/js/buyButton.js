const audio = new Audio("https://www.fesliyanstudios.com/play-mp3/4519");
const buttons = document.querySelectorAll(".buyBtn");

buttons.forEach(buyBtn => {
    buyBtn.addEventListener("click", () => {
      audio.play();
    });
  });
